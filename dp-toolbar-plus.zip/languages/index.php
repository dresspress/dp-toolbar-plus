<?php
//Silence is golden!